Madhumitha Birthday Website 💗

HOW TO USE:
1. Unzip this folder.
2. Open index.html in a browser.
3. To share it online, upload the whole folder to a static hosting service.

The website already includes the six uploaded photos.

SONG:
The "Play our song" button opens a YouTube search for "Un Vizhigalil - Maan Karate". No copyrighted audio file is bundled.

To change the message, edit the text inside index.html with any text editor.
